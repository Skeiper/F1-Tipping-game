from django.shortcuts import render

# Create your views here.
def F1(request):
    return render(request, "Tipper.html")