from django.db import models
from datetime import date
from django.utils.translation import gettext as _

class Weekend(models.Model):
    where = models.CharField(_("Location"), max_length=50)
    date = models.DateField(_("Event Date"), default=date.today)
    qualifiing = models.CharField(_("Qualifying Type"), max_length=50)
    sprint_qualifiing = models.CharField(_("Sprint Qualifying Type"), max_length=50)
    sprint = models.CharField(_("Sprint Race Type"), max_length=50)
    race = models.CharField(_("Race Type"), max_length=50)
